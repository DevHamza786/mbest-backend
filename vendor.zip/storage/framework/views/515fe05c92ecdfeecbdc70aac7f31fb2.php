<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Invoice <?php echo e($invoice->invoice_number); ?></title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .header {
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .logo {
            max-height: 60px;
            max-width: 200px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        .header-right {
            text-align: right;
        }
        .invoice-info {
            margin-bottom: 30px;
        }
        .invoice-info table {
            width: 100%;
            border-collapse: collapse;
        }
        .invoice-info td {
            padding: 5px 0;
        }
        .invoice-info td:first-child {
            font-weight: bold;
            width: 150px;
        }
        .billing-details {
            margin-bottom: 30px;
        }
        .billing-details table {
            width: 100%;
            border-collapse: collapse;
        }
        .billing-details td {
            padding: 5px;
            vertical-align: top;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .items-table th,
        .items-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .items-table th {
            background-color: #f5f5f5;
            font-weight: bold;
        }
        .items-table .text-right {
            text-align: right;
        }
        .total-section {
            margin-top: 20px;
            text-align: right;
        }
        .total-row {
            padding: 5px 0;
        }
        .total-row.total {
            font-size: 16px;
            font-weight: bold;
            border-top: 2px solid #333;
            padding-top: 10px;
            margin-top: 10px;
        }
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 10px;
            color: #666;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <?php
                $logoPath = public_path('logo.png');
                if (!file_exists($logoPath)) {
                    $logoPath = public_path('M.B.E.S.T-logo.png');
                }
            ?>
            <?php if(file_exists($logoPath)): ?>
                <img src="<?php echo e($logoPath); ?>" alt="Logo" class="logo">
            <?php endif; ?>
            <div>
                <h1>INVOICE</h1>
                <div style="margin-top: 5px;">
                    <strong>Invoice #:</strong> <?php echo e($invoice->invoice_number); ?>

                </div>
            </div>
        </div>
        <div class="header-right">
            <strong><?php echo e(config('app.name', 'MBEST')); ?></strong>
        </div>
    </div>

    <div class="invoice-info">
        <table>
            <tr>
                <td>Issue Date:</td>
                <td><?php echo e($invoice->issue_date->format('F d, Y')); ?></td>
            </tr>
            <tr>
                <td>Due Date:</td>
                <td><?php echo e($invoice->due_date->format('F d, Y')); ?></td>
            </tr>
            <tr>
                <td>Status:</td>
                <td>
                    <strong style="text-transform: uppercase; color: <?php echo e($invoice->status === 'paid' ? 'green' : ($invoice->status === 'overdue' ? 'red' : 'orange')); ?>;">
                        <?php echo e($invoice->status); ?>

                    </strong>
                </td>
            </tr>
            <?php if($invoice->period_start && $invoice->period_end): ?>
            <tr>
                <td>Billing Period:</td>
                <td><?php echo e($invoice->period_start->format('M d, Y')); ?> - <?php echo e($invoice->period_end->format('M d, Y')); ?></td>
            </tr>
            <?php endif; ?>
        </table>
    </div>

    <div class="billing-details">
        <table>
            <tr>
                <td style="width: 50%;">
                    <strong>Bill To:</strong><br>
                    <?php if($invoice->parent): ?>
                        <?php echo e($invoice->parent->name); ?><br>
                        <?php echo e($invoice->parent->email); ?>

                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
                <td style="width: 50%;">
                    <?php if($invoice->student && $invoice->student->user): ?>
                        <strong>Student:</strong><br>
                        <?php echo e($invoice->student->user->name); ?><br>
                        Grade: <?php echo e($invoice->student->grade ?? 'N/A'); ?>

                    <?php endif; ?>
                </td>
            </tr>
        </table>
    </div>

    <?php if($invoice->description): ?>
    <div style="margin-bottom: 20px;">
        <strong>Description:</strong><br>
        <?php echo e($invoice->description); ?>

    </div>
    <?php endif; ?>

    <table class="items-table">
        <thead>
            <tr>
                <th>Description</th>
                <th class="text-right">Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->description); ?></td>
                    <td class="text-right"><?php echo e(number_format($item->amount, 2)); ?> <?php echo e($invoice->currency); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="2" style="text-align: center; padding: 20px;">
                        No items
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="total-section">
        <div class="total-row">
            <strong>Subtotal:</strong> <?php echo e(number_format($invoice->amount, 2)); ?> <?php echo e($invoice->currency); ?>

        </div>
        <div class="total-row total">
            <strong>Total Amount:</strong> <?php echo e(number_format($invoice->amount, 2)); ?> <?php echo e($invoice->currency); ?>

        </div>
    </div>

    <?php if($invoice->paid_date): ?>
    <div style="margin-top: 20px; padding: 10px; background-color: #f0f9ff; border-left: 4px solid #0ea5e9;">
        <strong>Payment Information:</strong><br>
        Paid on: <?php echo e($invoice->paid_date->format('F d, Y')); ?><br>
        <?php if($invoice->payment_method): ?>
            Payment Method: <?php echo e($invoice->payment_method); ?><br>
        <?php endif; ?>
        <?php if($invoice->transaction_id): ?>
            Transaction ID: <?php echo e($invoice->transaction_id); ?>

        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if($invoice->notes): ?>
    <div style="margin-top: 20px;">
        <strong>Notes:</strong><br>
        <?php echo e($invoice->notes); ?>

    </div>
    <?php endif; ?>

    <div class="footer">
        <p>Thank you for your business!</p>
        <?php if($invoice->tutor && $invoice->tutor->user): ?>
            <p>Tutor: <?php echo e($invoice->tutor->user->name); ?></p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php /**PATH D:\Project\mbest\mbest-backend\laravel\resources\views/invoices/pdf.blade.php ENDPATH**/ ?>